import serial
print(serial.__version__)
import serial.tools.list_ports
import time
import threading


cur_tx = 125
cur_ty = 103
tar_tx = 125
tar_ty = 103
xref = 125
yref = 103

ser = serial.Serial('COM5', 115200)
def execute_servo_command():
    global cur_tx
    global cur_ty
    global tar_tx
    global tar_ty
    global ser
    global xref
    global yref
    while True:
        if cur_tx<tar_tx:
            cur_tx = cur_tx+1
            cmd = 'a'
            ser.write(cmd.encode("utf-8"))
        elif cur_tx>tar_tx:
            cur_tx = cur_tx-1
            cmd = 'b'
            ser.write(cmd.encode("utf-8"))

        if cur_ty<tar_ty:
            cur_ty = cur_ty+1
            cmd = 'c'
            ser.write(cmd.encode("utf-8"))
        elif cur_ty>tar_ty:
            cur_y = cur_ty-1
            cmd = 'd'
            ser.write(cmd.encode("utf-8"))

        if cur_tx!=tar_tx or cur_ty!=cur_ty:
            time.sleep(0.01)
