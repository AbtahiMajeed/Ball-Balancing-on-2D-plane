import cv2 as cv
import numpy as np

cap = cv.VideoCapture(1)
i = 0
cv.waitKey(5000)
while True:
    ret, frame = cap.read()
    if not ret: break
    cv.imshow('out of nowhere', frame)
    cv.imwrite('checker' + str(i)+'.jpg', frame)
    i=i+1
    cv.waitKey(500)
    if cv.waitKey(1) & 0xFF == ord('q'):
        break
    if i==100:
        break

cap.release()
cv.destroyAllWindows()