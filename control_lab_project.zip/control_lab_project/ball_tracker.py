import cv2 as cv
import numpy as np

DIM=(640, 480)
K=np.array([[686.8489177656485, 0.0, 327.34852015262766], [0.0, 688.7707956482607, 230.30171140482724], [0.0, 0.0, 1.0]])
D=np.array([[0.02804628590726814], [-1.4351726309828632], [8.421488083931044], [-19.21133954186303]])

#init_cap = cv.VideoCapture(1)
prev = None
dist = lambda x1,y1,x2,y2 : (x1-x2)**2 + (y1-y2)**2

def is_orange(rgb):
    if (rgb[2]>140) & (rgb[1]<130) & (rgb[1]>40): return True
    else : return False

while True:
    ret, org_frame = init_cap.read()
    if not ret: break
    #map1, map2 = cv.fisheye.initUndistortRectifyMap(K, D, np.eye(3), K, DIM, cv.CV_16SC2)
    #frame = cv.remap(org_frame, map1, map2, interpolation=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)
    bw_frame = np.zeros([480,640,3], dtype = np.uint8 )
    for i in range(480):
        for j in range(640):
            if is_orange(frame[i,j]) : bw_frame[i,j]=np.array([255,255,255])
            else : bw_frame[i,j] = np.array([0,0,0])

    gray = cv.cvtColor(bw_frame, cv.COLOR_BGR2GRAY)
    blur = cv.GaussianBlur(gray, (9, 9), 0)
    circles = cv.HoughCircles(blur, cv.HOUGH_GRADIENT, 1, 100, param1=70, param2=70, minRadius=30, maxRadius=200)
    if circles is not None:
        circle = np.uint16(np.around(circles))
        chosen = None
        print("found a circle")
        for i in circle[0, :]:
            if chosen is None: chosen = i
            if prev is not None:
                if dist(chosen[0], chosen[1], prev[0], prev[1]) <= dist(i[0], i[1], prev[0], prev[1]):
                    chosen = i

        cv.circle(frame, (chosen[0], chosen[1]), 1, (0, 100, 100), 3)
        cv.circle(frame, (chosen[0], chosen[1]), chosen[2], (255, 0, 255), 3)
        prev = chosen
    else : print("not found")
    cv.imshow("hudai", blur)
    if cv.waitKey(1) & 0xFF == ord('q'):
        break


init_cap.release()
cv.destroyAllWindows()