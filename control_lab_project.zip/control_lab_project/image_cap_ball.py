import cv2 as cv
import numpy as np

DIM=(640, 480)
K=np.array([[686.8489177656485, 0.0, 327.34852015262766], [0.0, 688.7707956482607, 230.30171140482724], [0.0, 0.0, 1.0]])
D=np.array([[0.02804628590726814], [-1.4351726309828632], [8.421488083931044], [-19.21133954186303]])

cap = cv.VideoCapture(1)
i=0;
while True :
    ret, frame = cap.read()
    if not ret: break
    map1, map2 = cv.fisheye.initUndistortRectifyMap(K, D, np.eye(3), K, DIM, cv.CV_16SC2)
    frame = cv.remap(frame, map1, map2, interpolation=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)
    cv.imshow("take a picture", frame)
    if cv.waitKey(1) & 0xFF == ord('t'):
        cv.imwrite('box'+str(i)+'.jpg', frame)
        i=i+1
    if cv.waitKey(1) & 0xFF == ord('q'):
        break