import cv2 as cv
import numpy as np

def is_orange(rgb):
    if (rgb[2]>140) & (rgb[1]<130) & (rgb[1]>40): return True
    else : return False

for i in range(38):
    frame = cv.imread('ball'+str(i)+'.jpg')
    #cv.imshow("what the hell", frame)
    for i in range(480):
        for j in range(640):
            if is_orange(frame[i,j]): frame[i,j] = np.array([0,0,0])
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    blur = cv.GaussianBlur(gray, (5,5), 0)

    circles = cv.HoughCircles(gray, cv.HOUGH_GRADIENT, 1.1, 40, param1=20, param2=30, minRadius=30, maxRadius=40)
    if circles is not None:
        circle = np.uint16(np.around(circles))
        print("found a circle")
        #for i in circle[0, :]:
        #    if chosen is None: chosen = i
        #    if prev is not None:
        #        if dist(chosen[0], chosen[1], prev[0], prev[1]) <= dist(i[0], i[1], prev[0], prev[1]):
        #           chosen = i
        for chosen in circle[0, :]:
            cv.circle(frame, (chosen[0], chosen[1]), 1, (0, 100, 100), 3)
            cv.circle(frame, (chosen[0], chosen[1]), chosen[2], (255, 0, 255), 3)

        #prev = chosen
    else:
        print("not found")
    cv.imshow("hudai", frame)
    cv.waitKey(1000)
    if cv.waitKey(1) & 0xFF==ord('q'):
        break


cv.destroyAllWindows()


def area(x1,y1,x2,y2,x3,y3):
    return x1*y2-y1*x2+x2*y3-y2*x3+x3*y1-y3*x1

def is_inside(poly, point):
    v = np.array([0,1,2,3,0])
    for i in range(4):
        id = area(poly[v[i],0,0], poly[v[i],0,1], poly[v[i+1],0,0], poly[v[i+1],0,1], point[0], point[1])
        if  id< 0 :
            return False
    return True

def findcen(frame, poly):
    wx=0
    wy=0
    n=0
    for i in range(480):
        for j in range(640):
            if frame[i,j]>20 and frame[i,j]<40:
                wx=wx+i
                wy=wy+j
                n=n+1
    return (int)(wx/n), (int)(wy/n)