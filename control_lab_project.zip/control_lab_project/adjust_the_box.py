import cv2 as cv
import numpy as np

cap = cv.VideoCapture(1)
DIM=(640, 480)
K=np.array([[686.8489177656485, 0.0, 327.34852015262766], [0.0, 688.7707956482607, 230.30171140482724], [0.0, 0.0, 1.0]])
D=np.array([[0.02804628590726814], [-1.4351726309828632], [8.421488083931044], [-19.21133954186303]])

xup = 445
xdown = 70
xmid = 257
yup = 405
ydown = 30
ymid = 217
box = np.array([[[xup,ydown]],[[xdown,ydown]],[[xdown,yup]],[[xup,yup]]])
def area(x1,y1,x2,y2,x3,y3):
    return x1*y2-y1*x2+x2*y3-y2*x3+x3*y1-y3*x1

cur_x = None
cur_y = None

def is_inside(poly, point):
    v = np.array([0,1,2,3,0])
    for i in range(4):
        id = area(poly[v[i],0,0], poly[v[i],0,1], poly[v[i+1],0,0], poly[v[i+1],0,1], point[0], point[1])
        if  id>0 :
            return False
    return True
def findcircle(gray, poly):
    wx = 0
    wy = 0
    n = 0
    nnn = 0
    nn = 0
    for i in range(ydown, yup):
        for j in range(xdown, xup):
            #if is_inside(poly,np.array([j,i])) == True:
            if True:
                #nnn=nnn+1
                #if cur_x is not None and (abs(i-cur_x)+abs(j-cur_y))>120:
                #    continue
                #nn = nn+1
                if gray[i,j]==0:
                    #print(str(i)+' '+str(j) +' '+str(gray[i,j]))
                    wx = wx + j
                    wy = wy + i
                    n = n + 1
    #print(str(n)+'  '+str(nn)+'   '+str(nnn))
    if n==0:
        return -1,-1
    print(n)
    cx=(int)(wx/n)
    cy=(int)(wy/n)
    return cx, cy

while True:
    ret,frame = cap.read()
    if not ret: break
    map1, map2 = cv.fisheye.initUndistortRectifyMap(K, D, np.eye(3), K, DIM, cv.CV_16SC2)
    frame = cv.remap(frame, map1, map2, interpolation=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)

    gray = cv.cvtColor(frame,cv.COLOR_BGR2GRAY)
    ret, gray = cv.threshold(gray,80,255,0)
    #print(np.shape(frame))
    #print(frame[415,93])
    #print(gray[438,372])


    #cv.imshow('gray',gray)
    #cv.waitKey(0)
    #box = np.array([[[545,35]],[[135,35]],[[135,445]],[[545,445]]])


    #cx , cy = findcircle(gray, box)
    wx = 0
    wy = 0
    n = 0
    nnn = 0
    nn = 0
    for i in range(ydown, yup):
        for j in range(xdown, xup):
            # if is_inside(poly,np.array([j,i])) == True:
            if True:
                # nnn=nnn+1
                # if cur_x is not None and (abs(i-cur_x)+abs(j-cur_y))>120:
                #    continue
                # nn = nn+1
                if gray[i, j] == 0:
                    # print(str(i)+' '+str(j) +' '+str(gray[i,j]))
                    wx = wx + j
                    wy = wy + i
                    n = n + 1
    # print(str(n)+'  '+str(nn)+'   '+str(nnn))
    cv.drawContours(frame, [box], -1, (0,0,255), 3)

    if n == 0:
        cv.imshow('fixed box', frame)
        if cv.waitKey(1) and 0xFF == ord('q'):
            break
        continue

    #print(n)
    cx = (int)(wx / n)
    cy = (int)(wy / n)
    if cx!=-1:
        cur_x = cx
        cur_y = cy
        print(str(cx)+'    '+str(cy))
        cv.circle(frame,(cx, cy),3,(0,255,0),4)
    cv.imshow('fixed box', frame)

    if cv.waitKey(1) and 0xFF==ord('q'):
        break

cap.release()
cv.destroyAllWindows()