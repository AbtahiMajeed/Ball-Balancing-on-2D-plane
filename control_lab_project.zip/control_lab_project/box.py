import cv2 as cv
import numpy as np

DIM=(640, 480)
K=np.array([[686.8489177656485, 0.0, 327.34852015262766], [0.0, 688.7707956482607, 230.30171140482724], [0.0, 0.0, 1.0]])
D=np.array([[0.02804628590726814], [-1.4351726309828632], [8.421488083931044], [-19.21133954186303]])

#   init_cap      is the distorted original image
#   org_frame     is numpy array of original numpy array
#   frame         is undistorted original numpy array
#   img           is undistorted binary image

map1, map2 = cv.fisheye.initUndistortRectifyMap(K, D, np.eye(3), K, DIM, cv.CV_16SC2)

init_cap = cv.VideoCapture(1)
k=0
while True :

    #if k==47 : break
    #frame = cv.imread('ball'+str(k)+'.jpg')
    #k=k+1
    ret, org_frame = init_cap.read()
    if not ret: break
    frame = cv.remap(org_frame, map1, map2, interpolation=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)

    img = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    ret, img = cv.threshold(img,120,255,0)

    contours, hierarchy = cv.findContours(img, 1, 2)
    best = None
    xx = 0
    yy = 0
    ww = 0
    hh = 0
    xx1 = 0
    yy1 = 0
    arc = 0
    arc_t = None
    for cnt in contours:
        x1, y1 = cnt[0][0]
        approx = cv.approxPolyDP(cnt, 0.06 * cv.arcLength(cnt, True), True)
        if cv.arcLength(cnt, True)>arc:
            arc = cv.arcLength(cnt,True)
            arc_t = approx
        if len(approx) == 4:
            x, y, w, h = cv.boundingRect(cnt)
            if (w>ww) & (h>hh) :
                best = approx
                xx1 = x1
                yy1 = y1
                ww = w
                hh = h
                xx = x
                yy = y
            #ratio = float(w) / h
            #if ratio >= 0.9 and ratio <= 1.1:
            #    img = cv.drawContours(img, [cnt], -1, (0, 255, 255), 3)
            #    cv.putText(img, 'Square', (x1, y1), cv.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
            #else:
            #    cv.putText(img, 'Rectangle', (x1, y1), cv.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            #    img = cv.drawContours(img, [cnt], -1, (0, 255, 0), 3)
    print(str(arc)+'  '+str(len(arc_t)))
    #print(str(ww) + ' ' + str(hh))
    frame = cv.drawContours(frame, [arc_t], -1, (0,255,0),3)
    if (ww>0) & (hh>0) :
        #print('goccha')
        #print(np.shape(best))
        print(best)
        for j in range(4):
            #cv.circle(frame,(best[j,0,0],best[j,0,1]),10,(255,0,0),3)
            cv.putText(frame, str(j) , (best[j,0,0],best[j,0,1]) , cv.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        #print(str(x)+' '+str(y)+' '+str(w)+' '+str(h))
        ratio = float(ww) / hh
        frame = cv.drawContours(frame, [best], -1, (0, 0, 255), 3)

    cv.imshow('just image', img)
    cv.imshow('frame', frame) 

    if cv.waitKey(1) & 0xFF == ord('q'):
        break

#init_cap.release()
cv.destroyAllWindows()