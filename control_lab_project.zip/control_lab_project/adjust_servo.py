
### arduino commanding ###
import serial
print(serial.__version__)
import serial.tools.list_ports
import time
import threading


#ports = serial.tools.list_ports.comports()
#serialinst = serial.Serial()
#
#portslist = []
#portVar = None
#for onePort in ports:
#    portslist.append(str(onePort))
#    print(str(onePort))
#
#val = input("Select Port: COM")
#
#for x in range(0, len(portslist)):
#    if portslist[x].startswith("COM" + str(val)):
#        portVar = "COM" + str(val)
#        print(portVar)
#
#serialinst.baudrate = 9600
#serial.port = portVar
#serialinst.open()
#
#while True:
#    command = input("Arduino Command: x***/y***: ")
#    serailinst.write(command.encode("utf-8"))
#
#    if command == 'exit':
#        exit()
##
ser = serial.Serial('COM5', 115200)
time.sleep(20)

cur_tx = 125
cur_ty = 61
tar_tx = 125
tar_ty = 61
xref = 125
yref = 61
def execute_servo_command():
    global cur_tx
    global cur_ty
    global tar_tx
    global tar_ty
    global ser
    global xref
    global yref
    while True:
        if cur_tx<tar_tx :#and cur_tx<xref+20:
            cur_tx = cur_tx+1
            cmd = 'a'
            ser.write(cmd.encode("utf-8"))
        elif cur_tx>tar_tx :#and cur_tx>xref-20:
            cur_tx = cur_tx-1
            cmd = 'b'
            ser.write(cmd.encode("utf-8"))

        if cur_ty<tar_ty :#and cur_ty<yref+20:
            cur_ty = cur_ty+1
            cmd = 'c'
            ser.write(cmd.encode("utf-8"))
        elif cur_ty>tar_ty :#and cur_ty>yref-20:
            cur_ty = cur_ty-1
            cmd = 'd'
            ser.write(cmd.encode("utf-8"))

        if cur_tx!=tar_tx or cur_ty!=cur_ty:
            time.sleep(0.0001)


threading.Thread(target=execute_servo_command).start()
while True:
     cmd = input("insert y: ")
     tar_ty = int(cmd)
