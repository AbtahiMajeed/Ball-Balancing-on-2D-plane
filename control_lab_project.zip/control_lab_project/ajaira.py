import tensorflow as tf
from tensorflow import keras

physical_devices = tf.config.list_physical_devices("GPU")
print(physical_devices)