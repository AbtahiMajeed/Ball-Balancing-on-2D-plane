import cv2 as cv
import numpy as np
from typing import List
import serial.tools.list_ports
import time
import threading
import PID as pid

############################ fisheye parameters ##########################


DIM=(640, 480)
K=np.array([[686.8489177656485, 0.0, 327.34852015262766], [0.0, 688.7707956482607, 230.30171140482724], [0.0, 0.0, 1.0]])
D=np.array([[0.02804628590726814], [-1.4351726309828632], [8.421488083931044], [-19.21133954186303]])
map1, map2 = cv.fisheye.initUndistortRectifyMap(K, D, np.eye(3), K, DIM, cv.CV_16SC2)

xup = 435+3
xdown = 80-3
xmid = 257
yup = 395+3
ydown = 40-3
ymid = 217
quad = np.array([[[xup,ydown]],[[xdown,ydown]],[[xdown,yup]],[[xup,yup]]])

print("initializing.......")



#####################     preframe     ####################


pre = cv.VideoCapture(1)
ret, preframe = pre.read()
#quad = np.array([[[545,35]],[[135,35]],[[135,445]],[[545,445]]])
preframe = cv.remap(preframe, map1, map2, interpolation=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)
preframe = cv.drawContours(preframe,[quad],-1,(0,0,255),3)
cv.imshow("PRE-FRAME",preframe)
cv.waitKey(0)
pre.release()
cv.destroyWindow("PRE-FRAME")
print("initialization is successfully done........")

prev_time = time.time()
cap = cv.VideoCapture(1)

##################################   functions #######################
dist = lambda x1,y1,x2,y2 : (x1-x2)**2 + (y1-y2)**2

def area(x1,y1,x2,y2,x3,y3):
    return x1*y2-y1*x2+x2*y3-y2*x3+x3*y1-y3*x1

def is_inside(poly, point):
    v = np.array([0,1,2,3,0])
    for i in range(4):
        id = area(poly[v[i],0,0], poly[v[i],0,1], poly[v[i+1],0,0], poly[v[i+1],0,1], point[0], point[1])
        if  id>0 :
            return False
    return True


cur_x = None
cur_y = None
px = 0
py = 0

def findcircle(holy, poly):
    wx = 0
    wy = 0
    n = 0
    for i in range(ydown, yup):
        for j in range(xdown, xup):
            # if is_inside(poly,np.array([j,i])) == True:
            if True:
                # nnn=nnn+1
                # if cur_x is not None and (abs(i-cur_x)+abs(j-cur_y))>120:
                #    continue
                if holy[i, j] == 0:
                    # print(str(i)+' '+str(j) +' '+str(gray[i,j]))
                    wx = wx + j
                    wy = wy + i
                    n = n + 1
    # print(str(n)+'  '+str(nn)+'   '+str(nnn))
    if n < 2000 or n>5000:
        return -1, -1
    cx = (int)(wx / n)
    cy = (int)(wy / n)
    #print(n)
    return cx, cy

def ln_pnt(p1, p2, p3):
    d=np.sqrt((float)(dist(p1[0],p1[1],p2[0],p2[1])))
    return area(p1[0],p1[1],p2[0],p2[1],p3[0],p3[1])/d


def position(pnt,poly):
    #mps = np.zeros([4,2],dtype = float)
    #v = np.array([0,1,2,3,0])
    #for i in range(4):
    #    mps[i] = np.array([(poly[v[i],0,0]+poly[v[i+1],0,0])/2.00, (poly[v[i],0,1]+poly[v[i+1],0,1])/2.00 ])
    #
    #return ln_pnt(mps[0],mps[1],pnt), ln_pnt(mps[1], mps[2], pnt)
    return pnt[0]-xmid , pnt[1]-ymid



ixi = 0
iyi = 0
def PID_response(r, r0, t, iri):
    kp = 0.26
    ki = 0.0001
    kd = 20000;
    r = (float)(r)*24.000/355.000
    r0 = (float)(r0)*24.000/355.000
    t = (float)(t)*1000.0
    if -10 <r and r<10:
        iri = iri + ki*r
    else: iri = 0
    obj = pid.PID(kp, ki, kd, 0)
    obj.setLims(-10, 10)
    total =  obj.compute(r,t)
    angle = round(((total + 100) * 40 / 200) - 20)
    return angle, iri

cur_tx = 125
cur_ty = 61
tar_tx = 125
tar_ty = 61
def execute_servo_command():
    global cur_tx
    global tar_tx
    global cur_ty
    global tar_ty
    global ser
    global xref
    global yref
    while True:
        if cur_tx<tar_tx:
            cur_tx = cur_tx+1
            cmd = 'a'
            ser.write(cmd.encode("utf-8"))
        elif cur_tx>tar_tx:
            cur_tx = cur_tx-1
            cmd = 'b'
            ser.write(cmd.encode("utf-8"))

        if cur_ty<tar_ty:
            cur_ty = cur_ty+1
            cmd = 'c'
            ser.write(cmd.encode("utf-8"))
        elif cur_ty>tar_ty:
            cur_ty = cur_ty-1
            cmd = 'd'
            ser.write(cmd.encode("utf-8"))
        #if cur_tx!=tar_tx and cur_ty!=tar_ty:
        #    time.sleep(0.0001)


#######################################       commanding setup            ###########################################

xref = 125   ### it is character code of 'm' ------ real angle 125
yref = 61   ### it is character code 'M' ------ real angle 103
ser = serial.Serial('COM5', 115200)
time.sleep(25)


threading.Thread(target=execute_servo_command).start()


print("here we go now.......")

############################    MAIN LOOP #####################

while True:
    cur_time = time.time()
    ret, frame = cap.read()
    if not ret: break

    frame = cv.remap(frame, map1, map2, interpolation=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

    #blur = cv.GaussianBlur(gray, (9, 9), 0)

    ret, img = cv.threshold(gray, 100, 255, 0)

    ################## this portion is to find original bounding box ###############

    #contours, hierarchy = cv.findContours(img, 1, 2)
    #
    #best = None
    #ww = 0
    #hh = 0
    #for cnt in contours:
    #    x1, y1 = cnt[0][0]
    #    arc_len = cv.arcLength(cnt,True)
    #    approx = cv.approxPolyDP(cnt, 0.05 * arc_len, True)
    #    if len(approx) == 4 and arc_len>1350 and arc_len<1800:
    #        x, y, w, h = cv.boundingRect(cnt)
    #        if (w/h)<0.9 or (w/h)>1.1 or 2*(w+h)>2100:
    #            continue
    #        if (w>ww) and (h>hh) :
    #            best = approx
    #            ww = w
    #            hh = h
    #
    #if (ww>0) & (hh>0) :
    #    print('goccha')
    #    print(np.shape(best))
    #    for j in range(4):
    #        cv.circle(frame,(best[j,0,0],best[j,0,1]),10,(255,0,0),3)
    #        cv.putText(frame, str(j) , (best[j,0,0],best[j,0,1]) , cv.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
    #    frame = cv.drawContours(frame, [best], -1, (0, 0, 255), 3)
    #    quad = best



    #frame = cv.drawContours(frame, [quad], -1, (0,0,255),3)
    d_x, d_y  = findcircle(img, quad)
    #cv.circle(frame, (d_x, d_y), 28, (0, 255, 0), 4)

    if d_x==-1:
        #cv.imshow("box & circle", frame)
        #if cv.waitKey(1) & 0xFF == ord('q'):
        #    break
        continue
    #if cur_x is None and d_x !=-1 :
        #time.sleep(0.1)
    #x,y = position(np.array([d_x,d_y]), quad)
    x = d_x-xmid
    y = d_y-ymid

    cmdx, ixi = PID_response(x,px,cur_time - prev_time, ixi)
    cmdy, iyi = PID_response(y,py,cur_time - prev_time, iyi)
    prev_time = cur_time

    print('cmdx: '+str(cmdx)+'   cmdy: '+str(cmdy))
    tar_ty = yref + min(20, max(-20, cmdy))
    tar_tx = xref+min(20,max(-20,cmdx))
    #ser.write(cmd.encode('utf-8'))

    #ser.write(cmd.encode('utf-8'))

    #cv.imshow("box & circle", frame)

    #if cv.waitKey(1) & 0xFF == ord('q'):
    #    break

cap.release()
cv.destroyAllWindows()
