import cv2 as cv
import numpy as np

frame = cv.imread('ball'+str(0)+'.jpg')
t=30
#cv.circle(frame,(322,236),30,(t,t,t),60)
#cv.imwrite('box'+str(0)+'.jpg',frame)

gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
cv.imshow('hudai', gray)
wx = 0
wy = 0
n = 0
ret, gray = cv.threshold(gray,80,255,0)
print(np.shape(ret))
for i in range(480):
    for j in range(640):
        if (gray[i,j]<50):
            wx = wx+i
            wy = wy+j
            n = n+1
cx = (int)(wx/n)
cy = (int)(wy/n)
print(str(cx)+' '+str(cy))

cv.circle(frame,(cx,cy),5,(255,255,0),10)
#cv.imshow('hudai',gray)
cv.imshow('frame',gray)
cv.waitKey(0)